package orderedPack;

import java.util.Arrays;

/**
* This class aOrderedList creates the array that stores the car objects and formats it into a string.
*
* CSC 1351 Programming Project No 1 Part A
* Section 2
*
* @author Stacy Nguyen
* @since 3/17/24
*
*/
public class aOrderedList {
	
	final int SIZEINCREMENTS = 20; //size of increments for increasing ordered list
	private Comparable[] oList; //the ordered list
	private int listSize; //the size of the ordered list
	private int numObjects; //the number of objects in the ordered list
	private int curr; //index of current element accessed via iterator methods
	
	/**
	* This method aOrderedList is a constructor that sets the numObjects, listSize, and oList.
	*
	* CSC 1351 Programming Project No 1 Part A
	* Section 2
	*
	* @author Stacy Nguyen
	* @since 3/17/24
	*
	*/
	public aOrderedList() {
		numObjects = 0; 
		listSize = SIZEINCREMENTS;
		oList = new Car[listSize];
	}
	
	/**
	* This method add adds newCar object to an array and sorts it to the right position.
	*
	* CSC 1351 Programming Project No 1 Part A
	* Section 2
	*
	* @author Stacy Nguyen
	* @since 3/17/24
	*
	*/
	public void add(Comparable newObject) {
		if (numObjects == listSize) {
			//Resizes the array if it is full.
			listSize += SIZEINCREMENTS;
//			Car[] tempArr = new Car[listSize]; //old code
//			//Copies elements of the array to the new array.
//			for (int i = 0; i < numObjects; i++) {
//				tempArr[i] = oList[i];
//			}
//			oList = tempArr;
			oList = Arrays.copyOf(oList, listSize);
		}
		//Finds where the correct position of the new car should go.
		int i = numObjects - 1;
		while (i >= 0 && oList[i].compareTo(newObject) > 0) {
			oList[i + 1] = oList[i];
			i--;
			}
		//Inserts the new car
		 oList[i + 1] = newObject;
		 numObjects++;
		}
	
	
	/**
	* This method toString creates the string for the oList array.
	*
	* CSC 1351 Programming Project No 1 Part A
	* Section 2
	*
	* @author Stacy Nguyen
	* @since 3/17/24
	*
	*/
	@Override
	public String toString() {
		String result = "[";
		for(int i = 0; i < numObjects; i++) {
			result += oList[i].toString();
			if (i < numObjects - 1) {
				result += ", ";
			}
		}
		result += "]";
        return result;
	}
	
	/**
	* This method size returns the number of elements in this list.
	*
	* CSC 1351 Programming Project No 1 Part A
	* Section 2
	*
	* @author Stacy Nguyen
	* @since 3/17/24
	*
	*/
	public int size() {
		return numObjects;
	}
	
	/**
	* This method get returns the element at the specified position in this list.
	*
	* CSC 1351 Programming Project No 1 Part A
	* Section 2
	*
	* @author Stacy Nguyen
	* @since 3/17/24
	*
	*/
	public Comparable get(int index) {
		if (index < 0 || index >= numObjects) {
			throw new IndexOutOfBoundsException("Index is out of bounds");	
		}
		return oList[index];
	}
	
	/**
	* This method isEmpty returns true if the array is empty and false otherwise.
	*
	* CSC 1351 Programming Project No 1 Part A
	* Section 2
	*
	* @author Stacy Nguyen
	* @since 3/17/24
	*
	*/
	public boolean isEmpty() {
		return numObjects == 0;
		}
	
	/**
	* This method remove removes the element at the specified position in this list.
	*
	* CSC 1351 Programming Project No 1 Part A
	* Section 2
	*
	* @author Stacy Nguyen
	* @since 3/17/24
	*
	*/
	public void remove(int index) {
		if (index < 0 || index >= numObjects) {
			throw new IndexOutOfBoundsException("Index is out of bounds");
		}
		for (int i = index; i < numObjects - 1; i++) {
			oList[i] = oList[i + 1];
		}
		oList[numObjects - 1] = null;
		numObjects--;
	}
	
	/**
	* This method reset resets iterator parameters so that the “next” element is the first element in the
	* array, if any.
	*
	* CSC 1351 Programming Project No 1 Part A
	* Section 2
	*
	* @author Stacy Nguyen
	* @since 3/17/24
	*
	*/
	public void reset() {
		 curr = 0;
	}

	/**
	* This method next returns the next element in the iteration and increments the iterator parameters.
	*
	* CSC 1351 Programming Project No 1 Part A
	* Section 2
	*
	* @author Stacy Nguyen
	* @since 3/17/24
	*
	*/
	public Comparable next() {
		Comparable nextElement = oList[curr]; //value of a specific position of oList.
		curr++;
		return nextElement;
	}

	/**
	* This method hasNext returns true if the iteration has more elements to iterate through.
	*
	* CSC 1351 Programming Project No 1 Part A
	* Section 2
	*
	* @author Stacy Nguyen
	* @since 3/17/24
	*
	*/
	public boolean hasNext() {
		 return curr < numObjects;
	}

	/**
	* This method delete deletes a car object from the array depending on its make and year.
	*
	* CSC 1351 Programming Project No 1 Part A
	* Section 2
	*
	* @author Stacy Nguyen
	* @since 3/17/24
	*
	*/
	public void delete(String Make, int Year) {
		for (int i = 0; i < numObjects; i++) {
			Car car = (Car) oList[i];
			if (car.getMake().equals(Make) && car.getYear() == Year) {
				remove(i);
				break;
			}
		}
	}
}
