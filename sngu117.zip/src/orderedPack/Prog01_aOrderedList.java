package orderedPack;

import java.io.*;
import java.util.Scanner;

/**
* This class Prog01_aOrderedList contains the scanner to check the filename that the user gives
* and check if it exist, printwriter that prints out a new file for the information in the file,
* and the main method.
*
* CSC 1351 Programming Project No 1 Part A
* Section 2
*
* @author Stacy Nguyen
* @since 3/17/24
*
*/
public class Prog01_aOrderedList {
	
	/**
	* This main method reads the file that the user input (if valid) and processes the data from
	* the file (on adding and deleting cars in a list). It then writes the updated data into a 
	* output file in the correct order (by Make/Year) while catching errors that may come from the user's input.
	*
	* CSC 1351 Programming Project No 1 Part A
	* Section 2
	*
	* @author Stacy Nguyen
	* @since 3/17/24
	*
	*/
	public static void main(String[] args) {
		Prog01_aOrderedList program = new Prog01_aOrderedList();
		aOrderedList orderedList = new aOrderedList();
		
		try {
            Scanner inputScanner = program.GetInputFile("Enter input filename: ");
            //If no exception is thrown, the inputScanner is successfully created.
            System.out.println("Scanner for input file created successfully.");
            
            while (inputScanner.hasNextLine()){
            	String line = inputScanner.nextLine(); //Takes in each line in the file.
            	String[] parts = line.split(","); //Array that separates each line by commas.
            	 if (parts.length == 4 && parts[0].equals("A")) {
            		String Make = parts[1]; //The make of the car that is in index 1 of the array.
            		int Year = Integer.parseInt(parts[2]); //The year of the car that is in index 2 of the array. Also converts string to int.
            		int Price = Integer.parseInt(parts[3]); //The price of the car that is in index 3 of the array. Also converts string to int.
            		Car car = new Car(Make, Year, Price); //Creates new car object.
            		orderedList.add(car);
            	}
            	 else if (parts.length == 3 && parts[0].equals("D")) {
            		 String make = parts[1]; //The make of the car that is in index 1 of the array.
            		 int year = Integer.parseInt(parts[2]); //The year of the car that is in index 2 of the array.
            		 orderedList.delete(make, year);
            	 }
            }
            inputScanner.close();
            
        } catch (FileNotFoundException e) {
            // Handle the case where the file is not found.
            System.out.println("File not found. Program execution terminated.");
            return;
        }
		
		try {
			PrintWriter outputWriter = program.GetOutputFile("Enter output filename: ");
			 System.out.println("Output file created successfully.");
//			outputWriter.println(orderedList.toString()); //old code
//			outputWriter.close();
			outputWriter.printf("%-10s %10s\n\n", "Number of cars:", orderedList.size());
			for (int i = 0; i < orderedList.size(); i++) {
				Car car = (Car) orderedList.get(i);
				outputWriter.printf("%-10s %10s\n", "Make:", car.getMake());
				outputWriter.printf("%-10s %10s\n", "Year:", car.getYear());
				outputWriter.printf("%-10s %10s\n", "Price:", "$" + String.format("%,d", car.getPrice()));
				if (i < orderedList.size() - 1) {
					outputWriter.println(); //adds blank line
				}
			}
			outputWriter.close();
		} catch (FileNotFoundException e){
			System.out.println("User cancelled program.");
		}
	}
	
	/**
	* This method GetInputFile asks the user for an existing file name and if it doesn't exist then the program asks the 
	* user to if they want to continue. If they respond with Y then the program runs again, if they respond with N then 
	* the program ends with the error.
	*
	* CSC 1351 Programming Project No 1 Part A
	* Section 2
	*
	* @author Stacy Nguyen
	* @since 3/17/24
	*
	*/
	public Scanner GetInputFile(String UserPrompt) throws FileNotFoundException{
		String fileName; //filename that the user inputs for the input file.
		Scanner in = new Scanner(System.in);
		Scanner fileScanner = null;
		
		while (fileScanner == null)
		{
			System.out.println(UserPrompt);
			fileName = in.nextLine();
			try {
				fileScanner = new Scanner(new File(fileName));
			} catch (FileNotFoundException e) {
				System.out.println("File specified <" + fileName + "> does not exist or cannot be created. Would you like to continue? <Y/N>");
				String userResponse = in.nextLine();
				if (!(userResponse.equals("Y")) && !(userResponse.equals("y"))){
					throw new FileNotFoundException();
				}
			}
		}
		return fileScanner;
	}
	
	/**
	* This method GetOutputFile asks the user to name the text output file and checks if it is valid. If the filename
	* is not valid then the program will run again until the user inputs a valid filename or cancels the program.
	*
	* CSC 1351 Programming Project No 1 Part A
	* Section 2
	*
	* @author Stacy Nguyen
	* @since 3/17/24
	*
	*/
	public PrintWriter GetOutputFile(String UserPrompt) throws FileNotFoundException{
		String fileName; //filename that the user inputs for the output file.
		Scanner in = new Scanner(System.in);
		PrintWriter printWriter = null;
		
		while (printWriter == null){
			System.out.println(UserPrompt);
			fileName = in.nextLine();
			try {
				printWriter = new PrintWriter(new File(fileName));
			} catch (FileNotFoundException e) {
				System.out.println("File specified <" + fileName + "> does not exist or cannot be created. Would you like to continue? <Y/N>");
				String userPrompt = in.nextLine();
				if (!(userPrompt.equals("Y")) && !(userPrompt.equals("y"))){
					throw new FileNotFoundException();
				}
			}
		}
		in.close();
		return printWriter;
	}
}