package orderedPack;

/**
* This class Car creates an object that has a make, year, and price.
*
* CSC 1351 Programming Project No 1 Part A
* Section 2
*
* @author Stacy Nguyen
* @since 3/17/24
*
*/
public class Car implements Comparable<Car> {
	private String make; //The make of the car
	private int year; //The year of the car
	private int price; //the price of the car
	
	/**
	* This method Car is a constructor that sets the value make, year, and price.
	*
	* CSC 1351 Programming Project No 1 Part A
	* Section 2
	*
	* @author Stacy Nguyen
	* @since 3/17/24
	*
	*/
	 public Car(String Make, int Year, int Price) {
		  make = Make;
		  year = Year;
		  price = Price;
	 }
	
	 /**
		* This method getMake returns the value of make.
		*
		* CSC 1351 Programming Project No 1 Part A
		* Section 2
		*
		* @author Stacy Nguyen
		* @since 3/17/24
		*
		*/
	 public String getMake() {
		 return make;
	 }
	 
	 /**
		* This method getYear returns the value of year.
		*
		* CSC 1351 Programming Project No 1 Part A
		* Section 2
		*
		* @author Stacy Nguyen
		* @since 3/17/24
		*
		*/ 
	 public int getYear() {
		 return year;
	 }
	 
	 /**
		* This method getPrice returns the value of price.
		*
		* CSC 1351 Programming Project No 1 Part A
		* Section 2
		*
		* @author Stacy Nguyen
		* @since 3/17/24
		*
		*/
	 public int getPrice() {
		 return price;
	 }
	
	 /**
		* This method compareTo compares car1(this.car) and car2(other.car). It compares the make of the cars and 
		* if the make is equal then the method compares the year.
		*
		* CSC 1351 Programming Project No 1 Part A
		* Section 2
		*
		* @author Stacy Nguyen
		* @since 3/17/24
		*
		*/
	 public int compareTo(Car other) {
		 if (this.make.compareTo(other.make) < 0) {
		        return -1;
		    } else if (this.make.compareTo(other.make) > 0) {
		        return 1;
		    }
		    else {
		    	if (this.year < other.year) {
		    		return -1;
		    	}
		    	else if (this.year > other.year) {
		    		return 1;	
		    	}
		    	else {
		    	return 0;	
		    	} 
		    }
	 }
	
	 /**
		* This method toString returns the value of make, year, and price in a string.
		*
		* CSC 1351 Programming Project No 1 Part A
		* Section 2
		*
		* @author Stacy Nguyen
		* @since 3/17/24
		*
		*/
	 @Override
	 public String toString() {
		 return "Make: " + make + ", Year : " + year + ", Price: " + price + ";"; 
	 }
	 
}
